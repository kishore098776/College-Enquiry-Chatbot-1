// Configuration
const MODEL_URL = './models';
let videoStream = null;

document.addEventListener('DOMContentLoaded', async () => {
    // Route logic based on page
    if (document.getElementById('videoElement')) {
        await setupRegistration();
    } else if (document.getElementById('attendanceVideo')) {
        await setupAttendance();
    } else if (document.getElementById('adminLoginBtn')) {
        setupAdminLogin();
    } else if (document.getElementById('statTotal')) {
        setupAdminDashboard();
    }
});

// Shared Model Loader
async function loadModels(statusElement, statusTextElement) {
    if (statusTextElement) statusTextElement.innerText = "Loading AI Models...";
    try {
        await Promise.all([
            faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
            faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
            faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
        ]);
        if (statusTextElement) statusTextElement.innerText = "Models Ready";
        return true;
    } catch (e) {
        console.error("Error loading models:", e);
        if (statusElement) {
            statusElement.className = "status-badge status-absent";
            statusTextElement.innerText = "Model Load Failed";
            statusElement.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> <span>Model Load Failed</span>`;
        }
        return false;
    }
}

// ==========================================
// REGISTRATION LOGIC
// ==========================================
async function setupRegistration() {
    const formPanel = document.getElementById('formPanel');
    const cameraPanel = document.getElementById('cameraPanel');
    const submitDetailsBtn = document.getElementById('submitDetailsBtn');
    const videoElement = document.getElementById('videoElement');
    const canvasElement = document.getElementById('canvasElement');
    const previewImage = document.getElementById('previewImage');
    const cameraPlaceholder = document.getElementById('cameraPlaceholder');
    const captureBtn = document.getElementById('captureBtn');
    const retakeBtn = document.getElementById('retakeBtn');
    const registerBtn = document.getElementById('registerBtn');
    const registerStatus = document.getElementById('registerStatus');

    let studentTempData = null;
    let currentFaceDescriptor = null;
    let currentPhotoBase64 = null;

    // Load AI logic in background
    await loadModels();

    submitDetailsBtn.addEventListener('click', async () => {
        const dept = document.getElementById('dept').value;
        const fullName = document.getElementById('fullName').value.trim();
        const rollNo = document.getElementById('rollNo').value.trim();

        if (!dept || !fullName || !rollNo) {
            alert("Please fill out all fields.");
            return;
        }

        studentTempData = { dept, fullName, rollNo };

        // UI Transition
        submitDetailsBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Initializing Camera...';
        submitDetailsBtn.disabled = true;

        try {
            videoStream = await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720, facingMode: "user" } });
            videoElement.srcObject = videoStream;
            videoElement.style.display = 'block';
            cameraPlaceholder.style.display = 'none';

            // Activate Camera Panel
            cameraPanel.style.opacity = '1';
            cameraPanel.style.pointerEvents = 'auto';
            captureBtn.style.display = 'inline-flex';

            // Lock Form Panel
            formPanel.style.opacity = '0.5';
            formPanel.style.pointerEvents = 'none';
            submitDetailsBtn.innerHTML = '<i class="fa-solid fa-check"></i> Details Locked';
            submitDetailsBtn.classList.replace('btn-primary', 'btn-success');
        } catch (err) {
            console.error("Camera error:", err);
            alert("Camera access denied.");
            submitDetailsBtn.innerHTML = 'Proceed to Camera <i class="fa-solid fa-arrow-right"></i>';
            submitDetailsBtn.disabled = false;
        }
    });

    captureBtn.addEventListener('click', async () => {
        // Flash effect
        cameraPanel.style.opacity = '0.7';
        setTimeout(() => cameraPanel.style.opacity = '1', 100);

        // Capture frame
        canvasElement.width = videoElement.videoWidth;
        canvasElement.height = videoElement.videoHeight;
        const ctx = canvasElement.getContext('2d');
        // flip canvas context if video is natively flipped CSS, face-api doesn't care about CSS flip
        ctx.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);

        const dataUrl = canvasElement.toDataURL('image/png');
        previewImage.src = dataUrl;

        videoElement.style.display = 'none';
        previewImage.style.display = 'block';

        captureBtn.style.display = 'none';
        retakeBtn.style.display = 'inline-flex';
        registerBtn.style.display = 'inline-flex';
        registerStatus.innerText = "Analyzing face...";
        registerBtn.disabled = true;

        // Detect Face
        const img = new Image();
        img.src = dataUrl;
        img.onload = async () => {
            const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();
            if (detection) {
                currentFaceDescriptor = Array.from(detection.descriptor);
                currentPhotoBase64 = dataUrl;
                registerStatus.innerHTML = '<span class="text-success"><i class="fa-solid fa-face-smile"></i> Face mapped successfully!</span>';
                registerBtn.disabled = false;
            } else {
                currentFaceDescriptor = null;
                registerStatus.innerHTML = '<span class="text-danger"><i class="fa-solid fa-triangle-exclamation"></i> No face detected. Please Retake.</span>';
            }
        };
    });

    retakeBtn.addEventListener('click', () => {
        previewImage.style.display = 'none';
        videoElement.style.display = 'block';

        captureBtn.style.display = 'inline-flex';
        retakeBtn.style.display = 'none';
        registerBtn.style.display = 'none';
        registerStatus.innerText = "";
        currentFaceDescriptor = null;
        currentPhotoBase64 = null;
    });

    registerBtn.addEventListener('click', () => {
        if (!currentFaceDescriptor) return;

        registerBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
        registerBtn.disabled = true;

        const newStudent = {
            id: Date.now().toString(),
            department: studentTempData.dept,
            fullName: studentTempData.fullName,
            rollNo: studentTempData.rollNo,
            faceDescriptor: currentFaceDescriptor,
            photoBase64: currentPhotoBase64,
            registrationTimestamp: new Date().toISOString()
        };

        const existing = JSON.parse(localStorage.getItem('registeredStudents')) || [];
        existing.push(newStudent);
        localStorage.setItem('registeredStudents', JSON.stringify(existing));

        registerStatus.innerHTML = '<span class="text-success" style="font-size:1.1rem; font-weight:bold;"><i class="fa-solid fa-circle-check"></i> Registration Complete!</span>';

        if (videoStream) videoStream.getTracks().forEach(t => t.stop());

        setTimeout(() => window.location.reload(), 2000);
    });
}

// ==========================================
// ATTENDANCE LOGIC
// ==========================================
async function setupAttendance() {
    const video = document.getElementById('attendanceVideo');
    const badge = document.getElementById('attendanceBadge');
    const statusText = document.getElementById('attendanceStatusText');
    const wrapper = document.getElementById('cameraWrapper');

    let attendanceCooldown = false;

    const modelsReady = await loadModels(badge, statusText);
    if (!modelsReady) return;

    try {
        videoStream = await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720, facingMode: "user" } });
        video.srcObject = videoStream;

        video.addEventListener('play', () => {
            statusText.innerText = "Scanner Ready | Look at Camera";
            startFaceRecognition(video, badge, statusText, wrapper, () => attendanceCooldown);
        });
    } catch (err) {
        badge.className = "status-badge status-absent";
        badge.innerHTML = `<i class="fa-solid fa-video-slash"></i> <span>Camera Access Denied</span>`;
    }

    async function startFaceRecognition(videoElem, badgeElem, textElem, wrapperElem, getCooldown) {
        const students = JSON.parse(localStorage.getItem('registeredStudents')) || [];

        if (students.length === 0) {
            badgeElem.className = "status-badge status-absent";
            badgeElem.innerHTML = `<i class="fa-solid fa-users-slash"></i> <span>No Users Registered</span>`;
            return;
        }

        const labeledDescriptors = students.map(s => {
            return new faceapi.LabeledFaceDescriptors(s.rollNo, [new Float32Array(s.faceDescriptor)]);
        });

        const faceMatcher = new faceapi.FaceMatcher(labeledDescriptors, 0.55);
        const tempCanvas = document.createElement('canvas');
        const ctx = tempCanvas.getContext('2d');
        let isDetecting = false;

        setInterval(async () => {
            if (getCooldown() || isDetecting || videoElem.paused) return;

            isDetecting = true;
            try {
                tempCanvas.width = videoElem.videoWidth;
                tempCanvas.height = videoElem.videoHeight;
                ctx.drawImage(videoElem, 0, 0, tempCanvas.width, tempCanvas.height);

                const detection = await faceapi.detectSingleFace(tempCanvas).withFaceLandmarks().withFaceDescriptor();

                if (detection) {
                    const match = faceMatcher.findBestMatch(detection.descriptor);

                    if (match.label === 'unknown') {
                        setUIState('absent', 'Unrecognized Face');
                    } else {
                        const studentDetails = students.find(s => s.rollNo === match.label);
                        setUIState('present', `Welcome, ${studentDetails.fullName}`, studentDetails);
                        logAttendance(studentDetails);

                        attendanceCooldown = true;
                        setTimeout(() => {
                            attendanceCooldown = false;
                            setUIState('scanning', 'Scanner Ready | Look at Camera');
                        }, 5000);
                    }
                } else {
                    if (!getCooldown()) setUIState('scanning', 'Scanning...');
                }
            } finally {
                isDetecting = false;
            }
        }, 300); // Super fast checking interval

        function setUIState(state, message, student = null) {
            textElem.innerText = message;
            const detailsCard = document.getElementById('scannedStudentDetails');

            if (state === 'scanning') {
                wrapperElem.className = "camera-wrapper status-scanning";
                badgeElem.className = "status-badge status-scanning";
                badgeElem.querySelector('i').className = "fa-solid fa-spinner";
                if (detailsCard) detailsCard.style.display = 'none';
            } else if (state === 'present') {
                wrapperElem.className = "camera-wrapper status-present";
                badgeElem.className = "status-badge status-present";
                badgeElem.querySelector('i').className = "fa-solid fa-circle-check";

                if (detailsCard && student) {
                    document.getElementById('detailName').innerText = student.fullName;
                    document.getElementById('detailRoll').innerText = student.rollNo;
                    document.getElementById('detailDept').innerText = student.department;
                    detailsCard.style.display = 'flex';
                }
            } else if (state === 'absent') {
                wrapperElem.className = "camera-wrapper status-absent";
                badgeElem.className = "status-badge status-absent";
                badgeElem.querySelector('i').className = "fa-solid fa-circle-xmark";
                if (detailsCard) detailsCard.style.display = 'none';
            }
        }
    }
}

function logAttendance(student) {
    const logs = JSON.parse(localStorage.getItem('attendanceLogs')) || [];
    const now = new Date();

    // Prevent double logging within 2 minutes
    const recentLog = logs.find(log =>
        log.rollNo === student.rollNo &&
        new Date(log.timestamp).toDateString() === now.toDateString() &&
        Math.abs(new Date(log.timestamp) - now) < 120000
    );

    if (!recentLog) {
        logs.push({
            rollNo: student.rollNo,
            name: student.fullName,
            dept: student.department,
            timestamp: now.toISOString()
        });
        localStorage.setItem('attendanceLogs', JSON.stringify(logs));
    }
}

// ==========================================
// ADMIN LOGIC
// ==========================================
function setupAdminLogin() {
    if (sessionStorage.getItem('isAdminLoggedIn') === 'true') {
        window.location.href = 'admin-dashboard.html';
    }

    document.getElementById('adminLoginBtn').addEventListener('click', () => {
        const u = document.getElementById('adminUser').value;
        const p = document.getElementById('adminPass').value;

        if (u === 'kishore' && p === '123') {
            sessionStorage.setItem('isAdminLoggedIn', 'true');
            window.location.href = 'admin-dashboard.html';
        } else {
            document.getElementById('loginError').style.display = 'block';
        }
    });
}

function setupAdminDashboard() {
    if (sessionStorage.getItem('isAdminLoggedIn') !== 'true') {
        window.location.href = 'admin.html';
    }

    document.getElementById('logoutBtn').addEventListener('click', () => {
        sessionStorage.removeItem('isAdminLoggedIn');
        window.location.href = 'admin.html';
    });

    const searchInput = document.getElementById('searchRoll');
    const filterSelect = document.getElementById('filterDept');

    searchInput.addEventListener('input', renderDashboard);
    filterSelect.addEventListener('change', renderDashboard);

    renderDashboard();
}

function renderDashboard() {
    const students = JSON.parse(localStorage.getItem('registeredStudents')) || [];
    const logs = JSON.parse(localStorage.getItem('attendanceLogs')) || [];

    const term = document.getElementById('searchRoll').value.toLowerCase();
    const deptFilter = document.getElementById('filterDept').value;
    const todayStr = new Date().toDateString();

    let presentTodayCount = 0;

    let attHtml = '';
    let studHtml = '';

    // Calculate global system working days
    // Working days will be the number of unique days AT LEAST ONE log exists since system started
    const allUniqueDates = [...new Set(logs.map(l => new Date(l.timestamp).toDateString()))];
    const systemWorkingDays = Math.max(1, allUniqueDates.length); // Avoid divide by zero

    students.forEach(s => {
        if (term && !s.rollNo.toLowerCase().includes(term) && !s.fullName.toLowerCase().includes(term)) return;
        if (deptFilter && s.department !== deptFilter) return;

        // Statistics
        const sLogs = logs.filter(l => l.rollNo === s.rollNo);
        const uniqueDaysPresent = [...new Set(sLogs.map(l => new Date(l.timestamp).toDateString()))].length;
        const todayLog = sLogs.find(l => new Date(l.timestamp).toDateString() === todayStr);

        if (todayLog) presentTodayCount++;

        // Detailed Metrics
        const presentCount = uniqueDaysPresent;
        // Absent count logic: system working days minus days the student was actually present.
        const absentCount = systemWorkingDays - presentCount;
        const attPercentage = Math.round((presentCount / systemWorkingDays) * 100);

        // Attendance Table Row
        const statusClass = todayLog ? 'badge-present' : 'badge-absent';
        const statusText = todayLog ? 'Present' : 'Absent';

        attHtml += `
            <tr>
                <td><strong>${s.rollNo}</strong></td>
                <td>${s.fullName}</td>
                <td>${s.department}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td><strong class="text-success">${presentCount}</strong></td>
                <td><strong class="text-danger">${absentCount}</strong></td>
                <td><strong style="color:var(--primary);">${attPercentage}%</strong></td>
            </tr>
        `;

        // Students Table Row
        const rDate = new Date(s.registrationTimestamp);
        const rDateStr = `${rDate.toLocaleDateString()} <small class="text-muted">${rDate.toLocaleTimeString()}</small>`;
        const photo = s.photoBase64 ? s.photoBase64 : 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';

        studHtml += `
            <tr>
                <td><img src="${photo}" class="student-photo"></td>
                <td><strong>${s.rollNo}</strong></td>
                <td>${s.fullName}</td>
                <td>${s.department}</td>
                <td>${rDateStr}</td>
                <td>
                    <button class="btn btn-outline" style="color: var(--danger); border-color: var(--danger); padding: 5px 10px; font-size: 0.85rem;" onclick="deleteStudent('${s.rollNo}')">
                        <i class="fa-solid fa-trash-can"></i> Delete
                    </button>
                </td>
            </tr>
        `;
    });

    document.getElementById('attendanceTableBody').innerHTML = attHtml || `<tr><td colspan="6" class="empty-state">No attendance records found matching filters.</td></tr>`;
    document.getElementById('studentsTableBody').innerHTML = studHtml || `<tr><td colspan="5" class="empty-state">No student records found matching filters.</td></tr>`;

    // Counters
    document.getElementById('statTotal').innerText = students.length;
    document.getElementById('statPresent').innerText = presentTodayCount;
    document.getElementById('statAbsent').innerText = students.length - presentTodayCount;
}

// Global Tab Switcher accessible from inline onclick
window.switchTab = function (tabId, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    document.getElementById('attendanceView').style.display = tabId === 'attendance' ? 'block' : 'none';
    document.getElementById('studentsView').style.display = tabId === 'students' ? 'block' : 'none';
};

// Global Delete Student function accessible from inline onclick
window.deleteStudent = function (rollNo) {
    if (confirm(`Are you sure you want to completely delete the student with Roll Number: ${rollNo}? This action cannot be undone.`)) {
        let students = JSON.parse(localStorage.getItem('registeredStudents')) || [];
        let logs = JSON.parse(localStorage.getItem('attendanceLogs')) || [];

        // Filter out the student
        students = students.filter(s => s.rollNo !== rollNo);
        logs = logs.filter(l => l.rollNo !== rollNo);

        // Save back to local storage
        localStorage.setItem('registeredStudents', JSON.stringify(students));
        localStorage.setItem('attendanceLogs', JSON.stringify(logs));

        // Re-render the dashboard immediately
        renderDashboard();
    }
};
