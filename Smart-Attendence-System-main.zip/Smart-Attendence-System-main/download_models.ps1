$baseurl = "https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/"
$models = @(
    "ssd_mobilenetv1_model-weights_manifest.json",
    "ssd_mobilenetv1_model-shard1",
    "ssd_mobilenetv1_model-shard2",
    "face_landmark_68_model-weights_manifest.json",
    "face_landmark_68_model-shard1",
    "face_recognition_model-weights_manifest.json",
    "face_recognition_model-shard1",
    "face_recognition_model-shard2"
)

$destDir = "c:\Users\kisho\OneDrive\Desktop\k\models"
if (!(Test-Path -Path $destDir)) {
    New-Item -ItemType Directory -Path $destDir
}

foreach ($model in $models) {
    $url = $baseurl + $model
    $destFile = Join-Path -Path $destDir -ChildPath $model
    Write-Host "Downloading $model..."
    Invoke-WebRequest -Uri $url -OutFile $destFile
}

$jsUrl = "https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/dist/face-api.min.js"
$jsDest = "c:\Users\kisho\OneDrive\Desktop\k\face-api.min.js"
Write-Host "Downloading face-api.min.js..."
Invoke-WebRequest -Uri $jsUrl -OutFile $jsDest

Write-Host "Done downloading face-api.js and models"
